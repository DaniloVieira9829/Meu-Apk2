import React, { useState, useEffect } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { useLocalStorage, exportDataAsJSON, importDataFromJSON, clearLocalStorage } from '@/hooks/useLocalStorage';
import Header from '@/components/Header';
import SummaryCards from '@/components/SummaryCards';
import TabNavigation from '@/components/TabNavigation';
import IncomeSection from '@/components/IncomeSection';
import ExpenseSection from '@/components/ExpenseSection';
import CalculatorSection from '@/components/CalculatorSection';
import ReportsSection from '@/components/ReportsSection';
import BudgetSection from '@/components/BudgetSection';
import { toast } from 'sonner';

export interface Income {
  id: string;
  description: string;
  value: number;
  date: string;
  recurrence: 'monthly' | 'biweekly' | 'once';
  nextDate?: string;
}

export interface Expense {
  id: string;
  description: string;
  value: number;
  category: string;
  date: string;
  paymentMethod?: string;
}

export interface Budget {
  category: string;
  limit: number;
}

export default function Dashboard() {
  const themeContext = useTheme();
  const theme = themeContext?.theme || 'light';
  const toggleTheme = themeContext?.toggleTheme || (() => {});
  const [activeTab, setActiveTab] = useState<'income' | 'expenses' | 'calculator' | 'reports' | 'budget'>('income');
  
  // Usar hook customizado para persistência automática com localStorage
  const [incomes, setIncomes] = useLocalStorage<Income[]>('incomes', []);
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('expenses', []);
  const [budgets, setBudgets] = useLocalStorage<Budget[]>('budgets', []);
  const [calculatorValue, setCalculatorValue] = useState<string>('');

  // Calculate totals
  const totalIncomes = incomes.reduce((sum, income) => sum + income.value, 0);
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.value, 0);
  const balance = totalIncomes - totalExpenses;
  const spendingPercentage = totalIncomes > 0 ? ((totalExpenses / totalIncomes) * 100).toFixed(1) : '0';

  const handleAddIncome = (income: Income) => {
    setIncomes([...incomes, income]);
    toast.success('Receita adicionada com sucesso!');
  };

  const handleDeleteIncome = (id: string) => {
    setIncomes(incomes.filter(income => income.id !== id));
    toast.success('Receita removida!');
  };

  const handleEditIncome = (id: string, updated: Income) => {
    setIncomes(incomes.map(income => income.id === id ? updated : income));
    toast.success('Receita atualizada!');
  };

  const handleAddExpense = (expense: Expense) => {
    setExpenses([...expenses, expense]);
    toast.success('Despesa adicionada com sucesso!');
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter(expense => expense.id !== id));
    toast.success('Despesa removida!');
  };

  const handleEditExpense = (id: string, updated: Expense) => {
    setExpenses(expenses.map(expense => expense.id === id ? updated : expense));
    toast.success('Despesa atualizada!');
  };

  const handleResetData = () => {
    if (window.confirm('⚠️ Tem certeza que deseja resetar TODOS os dados? Esta ação não pode ser desfeita!')) {
      clearLocalStorage(['incomes', 'expenses', 'budgets']);
      setIncomes([]);
      setExpenses([]);
      setBudgets([]);
      toast.success('Todos os dados foram resetados!');
    }
  };

  const handleExportPDF = () => {
    const element = document.createElement('div');
    element.innerHTML = `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h1 style="text-align: center; color: #333;">Resumo de Gastos</h1>
        <p style="text-align: center; color: #666;">Data de Geração: ${new Date().toLocaleDateString('pt-BR')}</p>
        
        <h2 style="color: #0066cc; margin-top: 20px;">Resumo Financeiro</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr style="background-color: #f0f0f0;">
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Total de Receitas</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: #27ae60;"><strong>R$ ${totalIncomes.toFixed(2)}</strong></td>
          </tr>
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Total de Despesas</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: #e74c3c;"><strong>R$ ${totalExpenses.toFixed(2)}</strong></td>
          </tr>
          <tr style="background-color: #f0f0f0;">
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>Saldo</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right; color: ${balance >= 0 ? '#27ae60' : '#e74c3c'};"><strong>R$ ${balance.toFixed(2)}</strong></td>
          </tr>
        </table>

        <h2 style="color: #0066cc; margin-top: 20px;">Receitas</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr style="background-color: #f0f0f0;">
            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Descrição</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Data</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Valor</th>
          </tr>
          ${incomes.map(income => `
            <tr>
              <td style="padding: 10px; border: 1px solid #ddd;">${income.description}</td>
              <td style="padding: 10px; border: 1px solid #ddd;">${new Date(income.date).toLocaleDateString('pt-BR')}</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">R$ ${income.value.toFixed(2)}</td>
            </tr>
          `).join('')}
        </table>

        <h2 style="color: #0066cc; margin-top: 20px;">Despesas</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr style="background-color: #f0f0f0;">
            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Descrição</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Categoria</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Data</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Valor</th>
          </tr>
          ${expenses.map(expense => `
            <tr>
              <td style="padding: 10px; border: 1px solid #ddd;">${expense.description}</td>
              <td style="padding: 10px; border: 1px solid #ddd;">${expense.category}</td>
              <td style="padding: 10px; border: 1px solid #ddd;">${new Date(expense.date).toLocaleDateString('pt-BR')}</td>
              <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">R$ ${expense.value.toFixed(2)}</td>
            </tr>
          `).join('')}
        </table>
      </div>
    `;

    const opt = {
      margin: 10,
      filename: `relatorio-gastos-${new Date().toISOString().split('T')[0]}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { orientation: 'portrait', unit: 'mm', format: 'a4' }
    };

    (window as any).html2pdf().set(opt).from(element).save();
    toast.success('PDF exportado com sucesso!');
  };

  const handleExportExcel = () => {
    const ws = (window as any).XLSX.utils.aoa_to_sheet([
      ['Relatório de Gastos', new Date().toLocaleDateString('pt-BR')],
      [],
      ['RECEITAS'],
      ['Descrição', 'Data', 'Valor', 'Recorrência'],
      ...incomes.map(income => [
        income.description,
        new Date(income.date).toLocaleDateString('pt-BR'),
        income.value,
        income.recurrence
      ]),
      [],
      ['DESPESAS'],
      ['Descrição', 'Categoria', 'Data', 'Valor', 'Forma de Pagamento'],
      ...expenses.map(expense => [
        expense.description,
        expense.category,
        new Date(expense.date).toLocaleDateString('pt-BR'),
        expense.value,
        expense.paymentMethod || '-'
      ]),
      [],
      ['RESUMO'],
      ['Total de Receitas', totalIncomes],
      ['Total de Despesas', totalExpenses],
      ['Saldo', balance]
    ]);

    const wb = (window as any).XLSX.utils.book_new();
    (window as any).XLSX.utils.book_append_sheet(wb, ws, 'Relatório');
    (window as any).XLSX.writeFile(wb, `relatorio-gastos-${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Excel exportado com sucesso!');
  };

  const handleExportData = () => {
    try {
      exportDataAsJSON(`relatorio-gastos-${new Date().toISOString().split('T')[0]}.json`);
      toast.success('Dados exportados com sucesso!');
    } catch (error) {
      toast.error('Erro ao exportar dados');
    }
  };

  const handleRestoreData = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = await importDataFromJSON(file);
      setIncomes(data.incomes);
      setExpenses(data.expenses);
      setBudgets(data.budgets);
      toast.success('Dados restaurados com sucesso!');
    } catch (error) {
      toast.error(`Erro ao restaurar: ${error}`);
    }
  };

  return (
    <div className={theme === 'dark' ? 'dark' : ''}>
      <div className="min-h-screen bg-background text-foreground">
        <Header onToggleTheme={toggleTheme} currentTheme={theme} />
        
        <main className="container mx-auto py-8">
          {/* Summary Cards */}
          <SummaryCards
            balance={balance}
            totalIncomes={totalIncomes}
            totalExpenses={totalExpenses}
            spendingPercentage={parseFloat(spendingPercentage)}
          />

          {/* Tab Navigation */}
          <div className="mt-8 mb-6">
            <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
          </div>

          {/* Tab Content */}
          <div className="mt-6">
            {activeTab === 'income' && (
              <IncomeSection
                incomes={incomes}
                onAddIncome={handleAddIncome}
                onDeleteIncome={handleDeleteIncome}
                onEditIncome={handleEditIncome}
              />
            )}

            {activeTab === 'expenses' && (
              <ExpenseSection
                expenses={expenses}
                onAddExpense={handleAddExpense}
                onDeleteExpense={handleDeleteExpense}
                onEditExpense={handleEditExpense}
                calculatorValue={calculatorValue}
              />
            )}

            {activeTab === 'calculator' && (
              <CalculatorSection
                value={calculatorValue}
                onChange={setCalculatorValue}
              />
            )}

            {activeTab === 'reports' && (
              <ReportsSection
                expenses={expenses}
                incomes={incomes}
                totalIncomes={totalIncomes}
                totalExpenses={totalExpenses}
                balance={balance}
                onExportPDF={handleExportPDF}
                onExportExcel={handleExportExcel}
                onExportData={handleExportData}
                onRestoreData={handleRestoreData}
                onResetData={handleResetData}
              />
            )}

            {activeTab === 'budget' && (
              <BudgetSection
                budgets={budgets}
                expenses={expenses}
                onUpdateBudgets={setBudgets}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
