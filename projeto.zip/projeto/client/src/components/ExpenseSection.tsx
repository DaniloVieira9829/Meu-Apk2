import React, { useState } from 'react';
import { Expense } from '@/pages/Dashboard';
import { nanoid } from 'nanoid';

interface ExpenseSectionProps {
  expenses: Expense[];
  onAddExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
  onEditExpense: (id: string, expense: Expense) => void;
  calculatorValue: string;
}

const CATEGORIES = [
  'Transporte',
  'Alimentação',
  'Lazer',
  'Moradia',
  'Saúde',
  'Educação',
  'Outros'
];

const PAYMENT_METHODS = [
  'Crédito',
  'Débito',
  'Dinheiro',
  'PIX'
];

export default function ExpenseSection({
  expenses,
  onAddExpense,
  onDeleteExpense,
  onEditExpense,
  calculatorValue
}: ExpenseSectionProps) {
  const [description, setDescription] = useState('');
  const [value, setValue] = useState(calculatorValue);
  const [category, setCategory] = useState('Alimentação');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string | null>(null);
  const [filterPaymentMethod, setFilterPaymentMethod] = useState<string | null>(null);

  React.useEffect(() => {
    if (calculatorValue) {
      setValue(calculatorValue);
    }
  }, [calculatorValue]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!description || !value) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    const expense: Expense = {
      id: editingId || nanoid(),
      description,
      value: parseFloat(value),
      category,
      date,
      paymentMethod: paymentMethod || undefined
    };

    if (editingId) {
      onEditExpense(editingId, expense);
      setEditingId(null);
    } else {
      onAddExpense(expense);
    }

    setDescription('');
    setValue('');
    setCategory('Alimentação');
    setDate(new Date().toISOString().split('T')[0]);
    setPaymentMethod('');
  };

  const handleEdit = (expense: Expense) => {
    setEditingId(expense.id);
    setDescription(expense.description);
    setValue(expense.value.toString());
    setCategory(expense.category);
    setDate(expense.date);
    setPaymentMethod(expense.paymentMethod || '');
  };

  const handleCancel = () => {
    setEditingId(null);
    setDescription('');
    setValue('');
    setCategory('Alimentação');
    setDate(new Date().toISOString().split('T')[0]);
    setPaymentMethod('');
  };

  const filteredExpenses = expenses.filter(expense => {
    if (filterCategory && expense.category !== filterCategory) return false;
    if (filterPaymentMethod && expense.paymentMethod !== filterPaymentMethod) return false;
    return true;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const categoryTotals = CATEGORIES.map(cat => ({
    category: cat,
    total: expenses.filter(e => e.category === cat).reduce((sum, e) => sum + e.value, 0)
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Form */}
      <div className="lg:col-span-1">
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">
            {editingId ? 'Editar Despesa' : 'Adicionar Despesa'}
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Descrição *</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Uber, iFood"
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Valor (R$) *</label>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="0.00"
                step="0.01"
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Categoria</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="input-field"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Data</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Forma de Pagamento</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="input-field"
              >
                <option value="">Selecione...</option>
                {PAYMENT_METHODS.map(method => (
                  <option key={method} value={method}>{method}</option>
                ))}
              </select>
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                className="btn-primary flex-1"
              >
                {editingId ? 'Atualizar' : 'Adicionar'}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className="btn-secondary flex-1"
                >
                  Cancelar
                </button>
              )}
            </div>
          </form>

          {/* Category Summary */}
          <div className="mt-6 pt-6 border-t border-border">
            <h4 className="font-medium mb-3">Resumo por Categoria</h4>
            <div className="space-y-2">
              {categoryTotals.map(({ category: cat, total }) => (
                total > 0 && (
                  <div key={cat} className="flex justify-between text-sm">
                    <span>{cat}</span>
                    <span className="font-medium">R$ {total.toFixed(2)}</span>
                  </div>
                )
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* List */}
      <div className="lg:col-span-2">
        <div className="card-summary">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold">Despesas Registradas ({filteredExpenses.length})</h3>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <select
              value={filterCategory || ''}
              onChange={(e) => setFilterCategory(e.target.value || null)}
              className="input-field text-sm"
            >
              <option value="">Todas as categorias</option>
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>

            <select
              value={filterPaymentMethod || ''}
              onChange={(e) => setFilterPaymentMethod(e.target.value || null)}
              className="input-field text-sm"
            >
              <option value="">Todos os pagamentos</option>
              {PAYMENT_METHODS.map(method => (
                <option key={method} value={method}>{method}</option>
              ))}
            </select>
          </div>

          {filteredExpenses.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <i className="fas fa-inbox text-4xl mb-4 block opacity-50"></i>
              <p>Nenhuma despesa registrada</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredExpenses.map((expense) => (
                <div
                  key={expense.id}
                  className="flex items-center justify-between p-4 bg-muted rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex-1">
                    <h4 className="font-medium">{expense.description}</h4>
                    <p className="text-sm text-muted-foreground">
                      {expense.category} • {new Date(expense.date).toLocaleDateString('pt-BR')}
                      {expense.paymentMethod && ` • ${expense.paymentMethod}`}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="badge-expense">
                      R$ {expense.value.toFixed(2)}
                    </div>

                    <button
                      onClick={() => handleEdit(expense)}
                      className="p-2 hover:bg-background rounded transition-colors"
                      title="Editar"
                    >
                      <i className="fas fa-edit text-blue-500"></i>
                    </button>

                    <button
                      onClick={() => onDeleteExpense(expense.id)}
                      className="p-2 hover:bg-background rounded transition-colors"
                      title="Deletar"
                    >
                      <i className="fas fa-trash text-red-500"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
