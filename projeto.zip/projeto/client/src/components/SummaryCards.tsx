import React from 'react';

interface SummaryCardsProps {
  balance: number;
  totalIncomes: number;
  totalExpenses: number;
  spendingPercentage: number;
}

export default function SummaryCards({
  balance,
  totalIncomes,
  totalExpenses,
  spendingPercentage
}: SummaryCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Balance Card */}
      <div className="card-summary">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">Saldo Atual</h3>
          <i className="fas fa-balance-scale text-xl" style={{ color: balance >= 0 ? 'oklch(0.65 0.2 142.495)' : 'oklch(0.577 0.245 27.325)' }}></i>
        </div>
        <p className="text-3xl font-bold" style={{ color: balance >= 0 ? 'oklch(0.65 0.2 142.495)' : 'oklch(0.577 0.245 27.325)' }}>
          R$ {balance.toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-2">
          {balance >= 0 ? '✓ Saldo positivo' : '✗ Saldo negativo'}
        </p>
      </div>

      {/* Income Card */}
      <div className="card-summary">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">Total de Receitas</h3>
          <i className="fas fa-arrow-up text-xl" style={{ color: 'oklch(0.65 0.2 142.495)' }}></i>
        </div>
        <p className="text-3xl font-bold" style={{ color: 'oklch(0.65 0.2 142.495)' }}>
          R$ {totalIncomes.toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-2">Receitas registradas</p>
      </div>

      {/* Expense Card */}
      <div className="card-summary">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">Total de Despesas</h3>
          <i className="fas fa-arrow-down text-xl" style={{ color: 'oklch(0.577 0.245 27.325)' }}></i>
        </div>
        <p className="text-3xl font-bold" style={{ color: 'oklch(0.577 0.245 27.325)' }}>
          R$ {totalExpenses.toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-2">Despesas registradas</p>
      </div>

      {/* Spending Percentage Card */}
      <div className="card-summary">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">% Gasto</h3>
          <i className="fas fa-chart-pie text-xl" style={{ color: 'oklch(0.7 0.2 70)' }}></i>
        </div>
        <p className="text-3xl font-bold" style={{ color: 'oklch(0.7 0.2 70)' }}>
          {spendingPercentage}%
        </p>
        <div className="w-full bg-muted rounded-full h-2 mt-3">
          <div
            className="h-2 rounded-full transition-all duration-300"
            style={{
              width: `${Math.min(spendingPercentage, 100)}%`,
              backgroundColor: spendingPercentage > 100 ? 'oklch(0.577 0.245 27.325)' : 'oklch(0.65 0.2 142.495)'
            }}
          ></div>
        </div>
      </div>
    </div>
  );
}
