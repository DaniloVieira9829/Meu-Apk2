import React from 'react';

interface HeaderProps {
  onToggleTheme: () => void;
  currentTheme: string;
}

export default function Header({ onToggleTheme, currentTheme }: HeaderProps) {
  return (
    <header className="bg-card text-card-foreground border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <i className="fas fa-wallet text-2xl" style={{ color: 'oklch(0.56 0.2 259.815)' }}></i>
          <div>
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Poppins', sans-serif" }}>
              Controle de Gastos
            </h1>
            <p className="text-sm text-muted-foreground">Organize suas finanças pessoais</p>
          </div>
        </div>

        <button
          onClick={onToggleTheme}
          className="p-2 rounded-lg bg-muted hover:bg-accent transition-colors duration-200"
          title={`Mudar para modo ${currentTheme === 'light' ? 'escuro' : 'claro'}`}
        >
          {currentTheme === 'light' ? (
            <i className="fas fa-moon text-lg"></i>
          ) : (
            <i className="fas fa-sun text-lg"></i>
          )}
        </button>
      </div>
    </header>
  );
}
