import React, { useState } from 'react';
import { Income } from '@/pages/Dashboard';
import { nanoid } from 'nanoid';

interface IncomeSectionProps {
  incomes: Income[];
  onAddIncome: (income: Income) => void;
  onDeleteIncome: (id: string) => void;
  onEditIncome: (id: string, income: Income) => void;
}

export default function IncomeSection({
  incomes,
  onAddIncome,
  onDeleteIncome,
  onEditIncome
}: IncomeSectionProps) {
  const [description, setDescription] = useState('');
  const [value, setValue] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [recurrence, setRecurrence] = useState<'monthly' | 'biweekly' | 'once'>('monthly');
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!description || !value) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    const income: Income = {
      id: editingId || nanoid(),
      description,
      value: parseFloat(value),
      date,
      recurrence
    };

    if (editingId) {
      onEditIncome(editingId, income);
      setEditingId(null);
    } else {
      onAddIncome(income);
    }

    setDescription('');
    setValue('');
    setDate(new Date().toISOString().split('T')[0]);
    setRecurrence('monthly');
  };

  const handleEdit = (income: Income) => {
    setEditingId(income.id);
    setDescription(income.description);
    setValue(income.value.toString());
    setDate(income.date);
    setRecurrence(income.recurrence);
  };

  const handleCancel = () => {
    setEditingId(null);
    setDescription('');
    setValue('');
    setDate(new Date().toISOString().split('T')[0]);
    setRecurrence('monthly');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Form */}
      <div className="lg:col-span-1">
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">
            {editingId ? 'Editar Receita' : 'Adicionar Receita'}
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Descrição *</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Salário mensal"
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Valor (R$) *</label>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="0.00"
                step="0.01"
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Data</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Recorrência</label>
              <select
                value={recurrence}
                onChange={(e) => setRecurrence(e.target.value as any)}
                className="input-field"
              >
                <option value="once">Única</option>
                <option value="biweekly">Quinzenal</option>
                <option value="monthly">Mensal</option>
              </select>
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                className="btn-primary flex-1"
              >
                {editingId ? 'Atualizar' : 'Adicionar'}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className="btn-secondary flex-1"
                >
                  Cancelar
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      {/* List */}
      <div className="lg:col-span-2">
        <div className="card-summary">
          <h3 className="text-xl font-bold mb-4">Receitas Registradas ({incomes.length})</h3>

          {incomes.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <i className="fas fa-inbox text-4xl mb-4 block opacity-50"></i>
              <p>Nenhuma receita registrada ainda</p>
            </div>
          ) : (
            <div className="space-y-3">
              {incomes.map((income) => (
                <div
                  key={income.id}
                  className="flex items-center justify-between p-4 bg-muted rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex-1">
                    <h4 className="font-medium">{income.description}</h4>
                    <p className="text-sm text-muted-foreground">
                      {new Date(income.date).toLocaleDateString('pt-BR')} • {
                        income.recurrence === 'monthly' ? 'Mensal' :
                        income.recurrence === 'biweekly' ? 'Quinzenal' : 'Única'
                      }
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="badge-income">
                      R$ {income.value.toFixed(2)}
                    </div>

                    <button
                      onClick={() => handleEdit(income)}
                      className="p-2 hover:bg-background rounded transition-colors"
                      title="Editar"
                    >
                      <i className="fas fa-edit text-blue-500"></i>
                    </button>

                    <button
                      onClick={() => onDeleteIncome(income.id)}
                      className="p-2 hover:bg-background rounded transition-colors"
                      title="Deletar"
                    >
                      <i className="fas fa-trash text-red-500"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
