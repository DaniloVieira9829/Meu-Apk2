import React, { useState } from 'react';

interface CalculatorSectionProps {
  value: string;
  onChange: (value: string) => void;
}

export default function CalculatorSection({ value, onChange }: CalculatorSectionProps) {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);

  const handleNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      setWaitingForNewValue(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleDecimal = () => {
    if (waitingForNewValue) {
      setDisplay('0.');
      setWaitingForNewValue(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  };

  const handleOperation = (op: string) => {
    const currentValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(currentValue);
    } else if (operation) {
      const result = calculate(previousValue, currentValue, operation);
      setDisplay(result.toString());
      setPreviousValue(result);
    }

    setOperation(op);
    setWaitingForNewValue(true);
  };

  const calculate = (prev: number, current: number, op: string): number => {
    switch (op) {
      case '+':
        return prev + current;
      case '-':
        return prev - current;
      case '*':
        return prev * current;
      case '/':
        return prev / current;
      default:
        return current;
    }
  };

  const handleEquals = () => {
    if (operation && previousValue !== null) {
      const currentValue = parseFloat(display);
      const result = calculate(previousValue, currentValue, operation);
      setDisplay(result.toString());
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const handleUseResult = () => {
    onChange(display);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Calculator */}
      <div className="card-summary h-fit">
        <h3 className="text-xl font-bold mb-4">Calculadora</h3>

        <div className="bg-muted rounded-lg p-4 mb-4">
          <div className="text-right text-4xl font-bold break-words">
            {display}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {/* Row 1 */}
          <button
            onClick={handleClear}
            className="btn-secondary col-span-2"
          >
            Limpar
          </button>
          <button
            onClick={() => handleOperation('/')}
            className="btn-secondary"
          >
            ÷
          </button>
          <button
            onClick={() => handleOperation('*')}
            className="btn-secondary"
          >
            ×
          </button>

          {/* Row 2 */}
          <button onClick={() => handleNumber('7')} className="btn-secondary">7</button>
          <button onClick={() => handleNumber('8')} className="btn-secondary">8</button>
          <button onClick={() => handleNumber('9')} className="btn-secondary">9</button>
          <button
            onClick={() => handleOperation('-')}
            className="btn-secondary"
          >
            −
          </button>

          {/* Row 3 */}
          <button onClick={() => handleNumber('4')} className="btn-secondary">4</button>
          <button onClick={() => handleNumber('5')} className="btn-secondary">5</button>
          <button onClick={() => handleNumber('6')} className="btn-secondary">6</button>
          <button
            onClick={() => handleOperation('+')}
            className="btn-secondary"
          >
            +
          </button>

          {/* Row 4 */}
          <button onClick={() => handleNumber('1')} className="btn-secondary">1</button>
          <button onClick={() => handleNumber('2')} className="btn-secondary">2</button>
          <button onClick={() => handleNumber('3')} className="btn-secondary">3</button>
          <button
            onClick={handleEquals}
            className="btn-primary"
          >
            =
          </button>

          {/* Row 5 */}
          <button
            onClick={() => handleNumber('0')}
            className="btn-secondary col-span-2"
          >
            0
          </button>
          <button
            onClick={handleDecimal}
            className="btn-secondary col-span-2"
          >
            ,
          </button>
        </div>

        <button
          onClick={handleUseResult}
          className="btn-primary w-full mt-4"
        >
          <i className="fas fa-arrow-right mr-2"></i>
          Usar Resultado
        </button>
      </div>

      {/* Instructions */}
      <div className="card-summary h-fit">
        <h3 className="text-xl font-bold mb-4">Como Usar</h3>

        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">Operações Básicas</h4>
            <p className="text-sm text-muted-foreground">
              Use os botões de números para digitar valores. Clique em +, −, ×, ÷ para operações matemáticas.
            </p>
          </div>

          <div>
            <h4 className="font-medium mb-2">Resultado</h4>
            <p className="text-sm text-muted-foreground">
              Clique em "=" para calcular o resultado da operação.
            </p>
          </div>

          <div>
            <h4 className="font-medium mb-2">Usar na Despesa</h4>
            <p className="text-sm text-muted-foreground">
              Após calcular, clique em "Usar Resultado" para preencher automaticamente o campo de valor na seção de despesas.
            </p>
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <p className="text-sm">
              <i className="fas fa-lightbulb mr-2" style={{ color: 'oklch(0.7 0.2 70)' }}></i>
              <strong>Dica:</strong> Você pode usar a calculadora para simular gastos antes de registrar.
            </p>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-border">
          <h4 className="font-medium mb-3">Valor Atual</h4>
          <div className="bg-muted p-3 rounded-lg">
            <p className="text-2xl font-bold">{display}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
